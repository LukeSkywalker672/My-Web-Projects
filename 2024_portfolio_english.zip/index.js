if(navigator.userAgentData.mobile) {
    //var boxes = document.getElementsByClassName("box");
    //alert("Mobile Device");
    for(var i = 0; i < document.getElementsByClassName("box").length;) {
        document.getElementsByClassName("box")[i++].style="flex-direction: column;";
        //alert("current:"+i+"\nMaximum: "+document.getElementsByClassName("box").length);
    }
    document.getElementById("projects").style = "display: flex; flex-direction: row; justify-content: center;";
}