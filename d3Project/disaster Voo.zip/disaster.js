let g_data = [];
let g_countryData = [];
const margin = { top: 20, right: 30, bottom: 40, left: 100 }; // Adjust left margin for readability
const width = 800 - margin.left - margin.right;
const height = 400 - margin.top - margin.bottom;

document.addEventListener("DOMContentLoaded", init);

function init() {
    console.log("----------  INIT()  ----------");
    d3.csv("1900_2021_DISASTERS_ascii_cleaned.csv").then((parsed) => {
        g_data = parsed.map((row) => {
            row.Year = parseInt(row.Year);
            row.Seq = parseInt(row.Seq);
            row.Magnitude = row.Magnitude === "" ? 0 : parseFloat(row.Magnitude);
            row.Total_Deaths = row.Total_Deaths === "" ? 0 : parseInt(row.Total_Deaths);
            return row;
        });
        generateCountryList();
        makeDiagrams();
    });
    console.log("----------  END INIT()  ----------");
}

function generateCountryList() {
    let countries = {};
    g_data.forEach((entry) => (countries[entry.Country] = entry.ISO));
    let countryArray = Object.entries(countries);
    countryArray.sort((a, b) => a[0].localeCompare(b[0]));
    let str = "";
    countryArray.forEach((c) => (str += `<option value="${c[1]}">${c[0]}</option>`));
    document.getElementById("nation").innerHTML = str;
}

function makeDiagrams() {
    console.log("----------  makeDiagrams()  ----------");
    d3.select("#Heatmap").select("svg").remove(); // Clear previous heatmap
    d3.select("#Scatterplot").select("svg").remove(); // Clear previous scatterplot
    g_countryData = filterByCountry(g_data);
    console.log("Filtered Country Data:", g_countryData);
    makeHeatmap();
    makeScatterplot();
}

function filterByCountry(input) {
    let ISO = document.getElementById("nation").value;
    return input.filter((row) => row.ISO === ISO);
}

function makeHeatmap() {
    const svg = d3.select("#Heatmap")
        .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    const years = Array.from(new Set(g_countryData.map(d => d.Year))).sort((a, b) => a - b);
    const disasterTypes = Array.from(new Set(g_countryData.map(d => d.Disaster_Type)));

    const xScale = d3.scaleBand()
        .domain(years)
        .range([0, width])
        .padding(0.05);

    const yScale = d3.scaleBand()
        .domain(disasterTypes)
        .range([0, height])
        .padding(0.05);

    // Calculate the frequency of each disaster type per year
    let frequencyData = {};
    disasterTypes.forEach(disasterType => {
        years.forEach(year => {
            const key = `${disasterType}-${year}`;
            const count = g_countryData.filter(d => d.Year === year && d.Disaster_Type === disasterType).length;
            frequencyData[key] = count;
        });
    });

    const maxFrequency = d3.max(Object.values(frequencyData));
    const colorScale = d3.scaleSequential(d3.interpolateYlOrRd)
        .domain([0, maxFrequency]);

    svg.append("g")
        .call(d3.axisTop(xScale).tickFormat(d3.format("d")));

    svg.append("g")
        .call(d3.axisLeft(yScale));

    disasterTypes.forEach(disasterType => {
        years.forEach(year => {
            const key = `${disasterType}-${year}`;
            const frequency = frequencyData[key] || 0;

            svg.append("rect")
                .attr("x", xScale(year))
                .attr("y", yScale(disasterType))
                .attr("width", xScale.bandwidth())
                .attr("height", yScale.bandwidth())
                .attr("fill", colorScale(frequency))
                .append("title")
                .text(`${disasterType}: ${frequency}`);
        });
    });

    // Add legend
    const legend = svg.append("g")
        .attr("transform", `translate(${width + 30}, 20)`);

    const legendScale = d3.scaleLinear()
        .domain([0, maxFrequency])
        .range([200, 0]);

    const legendAxis = d3.axisRight(legendScale)
        .ticks(6)
        .tickFormat(d3.format(".0f"));

    legend.append("g")
        .call(legendAxis);

    const legendGradient = svg.append("defs")
        .append("linearGradient")
        .attr("id", "legendGradient")
        .attr("x1", "0%")
        .attr("y1", "100%")
        .attr("x2", "0%")
        .attr("y2", "0%");

    legendGradient.append("stop")
        .attr("offset", "0%")
        .attr("stop-color", d3.interpolateYlOrRd(0));

    legendGradient.append("stop")
        .attr("offset", "100%")
        .attr("stop-color", d3.interpolateYlOrRd(1));

    legend.append("rect")
        .attr("x", -20)
        .attr("width", 20)
        .attr("height", 200)
        .style("fill", "url(#legendGradient)");
}

function makeScatterplot() {
    const margin = { top: 50, right: 50, bottom: 50, left: 50 };
    const width = 800 - margin.left - margin.right;
    const height = 400 - margin.top - margin.bottom;

    const svg = d3.select("#Scatterplot")
        .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    const earthquakeData = g_countryData.filter(d => d.Disaster_Type === "Earthquake");

    const xScale = d3.scaleLinear()
        .domain([0, d3.max(earthquakeData, d => +d.Total_Deaths)])
        .range([0, width]);

    const yScale = d3.scaleLinear()
        .domain([0, 10])
        .range([height, 0]);

    const xAxis = d3.axisBottom(xScale);
    const yAxis = d3.axisLeft(yScale);

    svg.append("g")
        .attr("transform", `translate(0, ${height})`)
        .call(xAxis)
        .append("text")
        .attr("x", width)
        .attr("y", -10)
        .attr("fill", "black")
        .style("text-anchor", "end")
        .text("Total Deaths");

    svg.append("g")
        .call(yAxis)
        .append("text")
        .attr("x", -10)
        .attr("y", 10)
        .attr("dy", ".75em")
        .attr("fill", "black")
        .style("text-anchor", "end")
        .text("Magnitude");

    svg.selectAll(".dot")
        .data(earthquakeData)
        .enter().append("circle")
        .attr("class", "dot")
        .attr("cx", d => xScale(d.Total_Deaths))
        .attr("cy", d => yScale(d.Magnitude))
        .attr("r", 3.5)
        .attr("fill", "blue")
        .append("title")
        .text(d => `Magnitude: ${d.Magnitude}, Deaths: ${d.Total_Deaths}`);
}